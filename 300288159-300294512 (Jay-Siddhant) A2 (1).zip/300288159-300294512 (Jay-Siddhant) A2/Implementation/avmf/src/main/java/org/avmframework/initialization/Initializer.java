package org.avmframework.initialization;

import org.avmframework.Vector;

public abstract class Initializer {

  public abstract void initialize(Vector vector);
}
