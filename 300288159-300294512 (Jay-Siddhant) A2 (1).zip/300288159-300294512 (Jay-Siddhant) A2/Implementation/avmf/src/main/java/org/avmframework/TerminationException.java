package org.avmframework;

public class TerminationException extends Exception {}
