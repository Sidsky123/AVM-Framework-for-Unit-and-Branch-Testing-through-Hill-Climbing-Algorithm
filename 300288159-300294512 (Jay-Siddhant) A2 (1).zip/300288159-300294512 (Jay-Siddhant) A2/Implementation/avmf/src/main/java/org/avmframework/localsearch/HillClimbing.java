package org.avmframework.localsearch;

import org.avmframework.TerminationException;
import org.avmframework.objective.ObjectiveValue;
import java.util.Random;

public class HillClimbing extends LocalSearch {

	protected ObjectiveValue initial;
	protected ObjectiveValue last;
	protected ObjectiveValue next;
	protected ObjectiveValue currentNext;
	protected int num;
	protected int goDirection;

	public HillClimbing() {
	}

	protected void performSearch() throws TerminationException {
		initialize();
		if (establishDirection()) {
			performHillClimbingSearch();
		}
	}

	protected void initialize() throws TerminationException {
		initial = objFun.evaluate(vector);
		num = var.getValue();
		goDirection = 0;
	}

	protected boolean establishDirection() throws TerminationException {
		// evaluate left move
		var.setValue(num - 1);
		ObjectiveValue left = objFun.evaluate(vector);

		// evaluate right move
		var.setValue(num + 1);
		ObjectiveValue right = objFun.evaluate(vector);

		// find the best direction
		boolean leftBetter = left.betterThan(initial);
		boolean rightBetter = right.betterThan(initial);
		if (leftBetter) {
			goDirection = -1;
		} else if (rightBetter) {
			goDirection = 1;
		} else {
			goDirection = 0;
		}

		// set num and the variable according to the best edge
		num += goDirection * 1;
		var.setValue(num);

		// set last and next objective values
		last = initial;
		if (goDirection == -1) {
			next = left;
		} else if (goDirection == 1) {
			next = right;
		} else if (goDirection == 0) {
			next = initial;
		}
		return goDirection != 0;
	}

	protected void performHillClimbingSearch() throws TerminationException {

		// creating rand object for finding random number
		Random rand = new Random();

		// initializing last and next as initial value
		last = initial;
		next = initial;

		// do the same thing for all the neighbours with different random numbers
		do {
			// run the loop till the current solution is better than previous
			last = next;
			int delta = 0;
			// generating all neighbours by running the loop x times. here, x = 60
			for (int i = 0; i < 60; i++) {

				// finding a random number between  -50 to +49
				int randomNumber = rand.nextInt(100) - (100 / 2);

				// setting the current variable as new one
				var.setValue(num + randomNumber);

				// evaluating the current solution
				currentNext = objFun.evaluate(vector);

				// if better, then update it
				if (currentNext.betterThan(next)) {
					delta = randomNumber;
					next = currentNext;
				}
			}
			// add the delta to current number and set it as new variable
			num += delta;
			var.setValue(num);
		} while (next.betterThan(last));
	}
}
